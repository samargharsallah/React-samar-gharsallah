import React from 'react';

const Experience = () => {
    return (
        <div className='experience'>
            <h3>Expérience</h3>
             <div  className='exp1'>
                <h4>License Informatique de gestion</h4>
                 <h5>IHEC Carthage | Depuis 2020</h5>
                 <p>Spécialité : Business Intelligence</p>
             </div>

             <div  className='exp2'>
                <h4>Stage chez Société de l'Automobile et du Matériel</h4>
                 <h5>Département Informatique</h5>
                 <p>- Maintenance d'un progiciel - Observation d'une manipulation d'une Base de Données - Découverte de la structure des serveurs</p>
             </div>


        </div>
    );
};

export default Experience;