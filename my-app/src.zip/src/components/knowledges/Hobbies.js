import React from 'react';

const Hobbies = () => {
    return (
       <div className='hobbies'>
            <h3> Intéret</h3>
            <ul>
              <li className='hobby'><i className='fas fa-running'></i> <span> Course à pied </span> </li>
              <li className='hobby'><i className='fas fa-swimming'></i> <span> Natation  </span> </li>
              <li className='hobby'><i className='fas fa-reading'></i> <span> Lecture des livres </span> </li>




            </ul>


       </div>
    );
};

export default Hobbies;