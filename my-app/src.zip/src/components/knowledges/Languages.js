import React, { Component } from 'react'
import ProgressBar from './ProgressBar';

export default class Languages extends Component {

    state= {
        Languages: [
            { id: 1, value: 'JavaScript', xp: 1.8},
            { id: 2, value: "CSS", xp: 1.8},
            { id: 3, value: "PHP", xp: 1.8},
            { id: 4, value: "Python", xp: 1.8}
        ]
    }


    render() {
       let {Languages} = this.state;

        return (
            <div className='Languages'>
                <ProgressBar
                 Languages={Languages} 
                 title="Languages"
                />
                   
            </div>
        )
    }
}


export default Languages;