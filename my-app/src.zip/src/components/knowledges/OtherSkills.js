import React from 'react';

const OtherSkills = () => {
    return (
        <div className='otherSkills'>
        <h3> Autres compétences</h3>
        <div className='list'></div>
        <ul>
         <li> <i className='fas fa-check-square'></i>  Anglais    </li>
         <li> <i className='fas fa-check-square'></i>  Français    </li>
         <li> <i className='fas fa-check-square'></i>  Methodes Agiles    </li>
         <li> <i className='fas fa-check-square'></i>  LMS    </li>
        </ul>
        
    </div>
    );
};

export default OtherSkills;