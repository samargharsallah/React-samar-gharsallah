import React from 'react';
import Navigation from '../components/Navigation';
import {copyToClipboard} from 'react-copy-to-clipboard'

const Contact = () => {
    return (
        <div className='contact'>
         <Navigation />   

         <div className='contactContent' >7
          <div className='header'></div>
             <div className='contactBox'></div>
              <h1> Contactez-moi</h1>
              <ul>
                <li> <i className='fas fa-map-marker-alt'></i> <span> Ariena Tunisie </span></li>
                <li> <i className='fas fa-mobile-alt'></i><CopyToClipboard text='+216 26434084' >
                    <span className='clickInput' onClick={() => {
                        alert('tel copié') ; }}> +216 26 434 084 </span> </CopyToClipboard></li>

                <li> <i className='far fa-envelope'></i><CopyToClipboard text='samargharsallah2@gmail.com' >
                    <span className='clickInput' onClick={() => {
                        alert('email copié') ; }}> samargharsallah2@gmail.com </span> </CopyToClipboard></li>


              </ul>
         </div>
        </div>
    );
};

export default Contact;