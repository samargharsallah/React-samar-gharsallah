import React from 'react';
import Navigation from '../components/Navigation';

const Home = () => {
    return (
        <div className='home'>
            <Navigation />
            <div className='homeContent'>
                <div className='content'>

                    <h1>Samar Gharsallah</h1>
                    <h2> Etudiante en Buisiness Intelligence </h2>
                    <div className='pdf'>
                        <a href='./media/Samar-Gharsallah.pdf'> Télecharger CV</a>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default Home;